"""
models/encoders.py
Wraps the pretrained configilm / BigEarthNet v2.0 classifiers as embedding
extractors (classification head removed), with a small trainable projection
head on top for metric learning.

IMPORTANT — VERIFY BEFORE FULL TRAINING RUS:
I could not re-verify the exact internal attribute names of
`BigEarthNetv2_0_ImageClassifier` against the live HuggingFace page while
writing this (search was unavailable), so `_extract_backbone()` below tries
several common patterns used by configilm/timm-based wrappers and falls back
to a forward-hook approach if none match. The very first time you run this,
call `inspect_model_structure(hf_repo_id)` (defined at the bottom of this file)
and visually confirm the printed architecture before trusting embeddings from
a full training run.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from config.config import EMBED_DIM, FREEZE_BACKBONE, BACKBONE_S1, BACKBONE_S2


def _load_pretrained_classifier(hf_repo_id: str):
    """Load the full pretrained BigEarthNet v2.0 classifier from HuggingFace."""
    from reben_publication.BigEarthNetv2_0_ImageClassifier import BigEarthNetv2_0_ImageClassifier
    model = BigEarthNetv2_0_ImageClassifier.from_pretrained(hf_repo_id)
    return model


def inspect_model_structure(hf_repo_id: str):
    """
    Debug helper — run this once per new backbone before training.
    Usage:
        from models.encoders import inspect_model_structure
        inspect_model_structure(BACKBONE_S2)
    """
    model = _load_pretrained_classifier(hf_repo_id)
    print(model)
    return model


def _extract_backbone_and_feat_dim(full_model: nn.Module):
    """
    Try several common attribute paths used by configilm/timm wrappers to find
    the feature-extracting backbone (i.e. everything before the final linear
    classification layer), and the dimensionality of its output features.

    Returns:
        backbone (nn.Module) — callable, returns (B, feat_dim) when given input
        feat_dim (int)
    """
    candidates = ["model", "vision_encoder", "encoder", "backbone", "net"]

    base = full_model
    for attr in candidates:
        if hasattr(full_model, attr):
            inner = getattr(full_model, attr)
            if isinstance(inner, nn.Module):
                base = inner
                break

    # If this is a timm model (resnet/vit/convnext all are in timm), the
    # standard, robust way to get pre-logit features is forward_features +
    # forward_head(..., pre_logits=True). This works regardless of the exact
    # head structure (Linear, Sequential, etc.) and is the recommended timm API.
    if hasattr(base, "forward_features") and hasattr(base, "forward_head"):
        class TimmFeatureWrapper(nn.Module):
            def __init__(self, timm_model):
                super().__init__()
                self.timm_model = timm_model

            def forward(self, x):
                feats = self.timm_model.forward_features(x)
                pooled = self.timm_model.forward_head(feats, pre_logits=True)
                return pooled

        wrapper = TimmFeatureWrapper(base)
        with torch.no_grad():
            dummy_channels = base.conv1.in_channels if hasattr(base, "conv1") else 3
            dummy = torch.zeros(1, dummy_channels, 120, 120)
            try:
                feat_dim = wrapper(dummy).shape[-1]
            except Exception:
                feat_dim = None
        if feat_dim is not None:
            return wrapper, feat_dim

    # Fallback: register a forward hook on the LAST nn.Linear in the whole
    # model (almost always the classification head) and capture its INPUT,
    # which is exactly the pre-logit embedding regardless of architecture.
    last_linear = None
    for module in full_model.modules():
        if isinstance(module, nn.Linear):
            last_linear = module
    if last_linear is None:
        raise RuntimeError(
            "Could not locate a backbone or a final Linear layer automatically. "
            "Run inspect_model_structure() and adjust _extract_backbone_and_feat_dim() "
            "manually for this specific checkpoint."
        )

    captured = {}

    def hook(module, inp, out):
        captured["features"] = inp[0]

    last_linear.register_forward_hook(hook)
    feat_dim = last_linear.in_features

    class HookWrapper(nn.Module):
        def __init__(self, full_model):
            super().__init__()
            self.full_model = full_model

        def forward(self, x):
            _ = self.full_model(x)
            return captured["features"]

    return HookWrapper(full_model), feat_dim


class PretrainedModalityEncoder(nn.Module):
    """
    One modality's encoder: pretrained backbone (frozen or fine-tunable)
    + trainable projection head -> L2-normalized embedding.
    """

    def __init__(self, hf_repo_id: str, embed_dim: int = EMBED_DIM,
                 freeze_backbone: bool = FREEZE_BACKBONE):
        super().__init__()
        full_model = _load_pretrained_classifier(hf_repo_id)
        self.backbone, feat_dim = _extract_backbone_and_feat_dim(full_model)

        if freeze_backbone:
            for p in self.backbone.parameters():
                p.requires_grad = False
            self.backbone.eval()

        self.freeze_backbone = freeze_backbone

        self.proj = nn.Sequential(
            nn.Linear(feat_dim, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True),
            nn.Linear(512, embed_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.freeze_backbone:
            with torch.no_grad():
                feat = self.backbone(x)
        else:
            feat = self.backbone(x)
        emb = self.proj(feat)
        return F.normalize(emb, dim=1)

    def set_finetune_mode(self, finetune: bool):
        """Call this to unfreeze the backbone for a later training phase."""
        self.freeze_backbone = not finetune
        for p in self.backbone.parameters():
            p.requires_grad = finetune
        self.backbone.train(finetune)


def build_encoders(device):
    """Build SAR and MS encoders from the currently selected backbones in config."""
    sar_enc = PretrainedModalityEncoder(BACKBONE_S1).to(device)
    ms_enc = PretrainedModalityEncoder(BACKBONE_S2).to(device)
    return sar_enc, ms_enc
