"""
data/dataset.py
Triplet sampling dataset: returns (anchor, positive, negative) for metric learning,
mixing cross-modal and same-modal pairs according to CROSS_MODAL_RATIO.
"""

import numpy as np
import torch
from torch.utils.data import Dataset

from config.config import KEEP_CLASSES, CLASS_TO_IDX, CROSS_MODAL_RATIO
from data.preprocessing import load_sar, load_ms


class BigEarthMMDataset(Dataset):
    def __init__(self, df, split: str, cross_modal_ratio: float = CROSS_MODAL_RATIO, seed: int = 0):
        self.df = df[df["split"] == split].reset_index(drop=True)
        self.ratio = cross_modal_ratio
        self.rng = np.random.default_rng(seed)

        self.cls_idx = {
            cls: self.df.index[self.df["primary_label"] == cls].tolist()
            for cls in KEEP_CLASSES
        }

    def __len__(self):
        return len(self.df)

    def _load(self, row, modality: str) -> torch.Tensor:
        return load_sar(row["s1_name"]) if modality == "SAR" else load_ms(row["patch_id"])

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        anchor_cls = row["primary_label"]
        anchor_mod = self.rng.choice(["SAR", "MS"])
        anchor = self._load(row, anchor_mod)

        if self.rng.random() < self.ratio:
            pos_mod = "MS" if anchor_mod == "SAR" else "SAR"
            pos = self._load(row, pos_mod)
        else:
            same = [i for i in self.cls_idx[anchor_cls] if i != idx] or self.cls_idx[anchor_cls]
            pos_row = self.df.iloc[self.rng.choice(same)]
            pos_mod = anchor_mod
            pos = self._load(pos_row, pos_mod)

        neg_cls = self.rng.choice([c for c in KEEP_CLASSES if c != anchor_cls])
        neg_row = self.df.iloc[self.rng.choice(self.cls_idx[neg_cls])]
        neg_mod = self.rng.choice(["SAR", "MS"])
        neg = self._load(neg_row, neg_mod)

        return {
            "anchor": anchor, "positive": pos, "negative": neg,
            "anchor_cls": CLASS_TO_IDX[anchor_cls],
            "anchor_mod": anchor_mod, "pos_mod": pos_mod,
        }
