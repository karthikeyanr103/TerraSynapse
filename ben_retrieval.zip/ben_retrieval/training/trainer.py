"""
training/trainer.py
Since the backbones are pretrained BigEarthNet v2.0 weights (not ImageNet),
the default and recommended mode is FREEZE_BACKBONE=True: only the small
projection heads get trained. This is fast (no GPU needed for the backbone
forward pass to be expensive) and well suited to a tight deadline.

If you have time/compute to spare, set FREEZE_BACKBONE=False in config.py
and a second fine-tuning phase will run automatically after the projection-
only phase.
"""

import torch
from tqdm import tqdm

from config.config import (BATCH_SIZE, EPOCHS_PROJ_ONLY, EPOCHS_FINETUNE,
                            LR_PROJ, LR_ENC, MARGIN, CKPT_DIR, FREEZE_BACKBONE)
from training.loss import TripletLoss


def get_optimizer(sar_enc, ms_enc, phase: str):
    proj_params = list(sar_enc.proj.parameters()) + list(ms_enc.proj.parameters())

    if phase == "proj_only":
        return torch.optim.Adam(proj_params, lr=LR_PROJ)

    # finetune phase — backbones already unfrozen by set_finetune_mode()
    enc_params = list(sar_enc.backbone.parameters()) + list(ms_enc.backbone.parameters())
    return torch.optim.Adam([
        {"params": enc_params, "lr": LR_ENC},
        {"params": proj_params, "lr": LR_PROJ},
    ])


def encode_batch(batch, sar_enc, ms_enc, device):
    B = batch["anchor"].shape[0]
    embed_dim = sar_enc.proj[-1].out_features
    emb_a = torch.zeros(B, embed_dim, device=device)
    emb_p = torch.zeros_like(emb_a)
    emb_n = torch.zeros_like(emb_a)

    for i in range(B):
        a_enc = sar_enc if batch["anchor_mod"][i] == "SAR" else ms_enc
        p_enc = sar_enc if batch["pos_mod"][i] == "SAR" else ms_enc
        n_enc = sar_enc  # negatives sampled as SAR in this simple loop; extend as needed
        emb_a[i] = a_enc(batch["anchor"][i:i + 1].to(device))
        emb_p[i] = p_enc(batch["positive"][i:i + 1].to(device))
        emb_n[i] = n_enc(batch["negative"][i:i + 1].to(device))

    return emb_a, emb_p, emb_n


def run_one_phase(phase_name, n_epochs, train_loader, sar_enc, ms_enc, criterion, device, best_loss):
    optimizer = get_optimizer(sar_enc, ms_enc, phase_name)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(n_epochs, 1))

    for epoch in range(n_epochs):
        sar_enc.train()
        ms_enc.train()
        total_loss = 0.0
        d_pos_running, d_neg_running = 0.0, 0.0

        pbar = tqdm(train_loader, desc=f"[{phase_name}] Epoch {epoch + 1}/{n_epochs}", unit="batch")
        for batch in pbar:
            optimizer.zero_grad()
            a, p, n = encode_batch(batch, sar_enc, ms_enc, device)
            loss, d_pos, d_neg = criterion(a, p, n)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            d_pos_running += d_pos
            d_neg_running += d_neg
            pbar.set_postfix(loss=f"{loss.item():.4f}")

        scheduler.step()
        avg_loss = total_loss / len(train_loader)
        print(f"  [{phase_name}] Epoch {epoch + 1}/{n_epochs}  "
              f"avg_loss={avg_loss:.4f}  d_pos={d_pos_running/len(train_loader):.4f}  "
              f"d_neg={d_neg_running/len(train_loader):.4f}")

        if avg_loss < best_loss:
            best_loss = avg_loss
            torch.save({
                "sar_enc": sar_enc.state_dict(),
                "ms_enc": ms_enc.state_dict(),
                "phase": phase_name,
                "epoch": epoch,
                "loss": avg_loss,
            }, CKPT_DIR / "best_model.pt")

    return best_loss


def run_training(train_loader, val_loader, sar_enc, ms_enc, device):
    """
    sar_enc, ms_enc are already-built PretrainedModalityEncoder instances
    (see models/encoders.py build_encoders()). Passed in rather than built
    here so you can swap backbones between runs without touching this file.
    """
    CKPT_DIR.mkdir(parents=True, exist_ok=True)
    criterion = TripletLoss(margin=MARGIN)
    best_loss = float("inf")

    print(f"\n=== Phase 1: projection heads only ({EPOCHS_PROJ_ONLY} epochs) ===")
    best_loss = run_one_phase("proj_only", EPOCHS_PROJ_ONLY, train_loader,
                               sar_enc, ms_enc, criterion, device, best_loss)

    if not FREEZE_BACKBONE:
        print(f"\n=== Phase 2: full fine-tune ({EPOCHS_FINETUNE} epochs) ===")
        sar_enc.set_finetune_mode(True)
        ms_enc.set_finetune_mode(True)
        best_loss = run_one_phase("finetune", EPOCHS_FINETUNE, train_loader,
                                   sar_enc, ms_enc, criterion, device, best_loss)

    print(f"\nTraining complete. Best loss: {best_loss:.4f}")
    print(f"Best checkpoint saved to: {CKPT_DIR / 'best_model.pt'}")
    return sar_enc, ms_enc
