# notebooks/02_train_retrieval_model.md
## Kaggle Notebook 2 — Training

Create `02-train-retrieval-model`. Attach the same private dataset.
**Turn ON GPU** (Settings -> Accelerator -> GPU T4 x2 or P100).

---

### Cell 1 — Clone code + install
```python
!git clone https://github.com/<YOUR_USERNAME>/<YOUR_REPO>.git /kaggle/working/repo
%cd /kaggle/working/repo
!pip install -q -r requirements.txt
```

### Cell 2 — Imports
```python
import sys
sys.path.insert(0, "/kaggle/working/repo")

import torch
import pandas as pd
from torch.utils.data import DataLoader

from config.config import (METADATA, BATCH_SIZE, BACKBONE_KEY_S1,
                            BACKBONE_KEY_S2, FREEZE_BACKBONE, CKPT_DIR)
from data.dataset import BigEarthMMDataset
from models.encoders import build_encoders, inspect_model_structure
from training.trainer import run_training

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Device: {device}")
print(f"Backbones in use -> S1: {BACKBONE_KEY_S1}, S2: {BACKBONE_KEY_S2}")
print(f"Freeze backbone: {FREEZE_BACKBONE}")
```

### Cell 3 — (Optional, first run only) inspect the pretrained model structure
```python
from config.config import BACKBONE_S2
_ = inspect_model_structure(BACKBONE_S2)
# Read the printed architecture. Confirm models/encoders.py's
# _extract_backbone_and_feat_dim() found a sensible feature dimension —
# you'll see this confirmed by the next cell's "feat_dim" print if you add one,
# or simply trust it if training loss decreases normally in Cell 6.
```

### Cell 4 — Load data
```python
df = pd.read_csv(METADATA)
train_ds = BigEarthMMDataset(df, split="train")
val_ds   = BigEarthMMDataset(df, split="validation")

train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=2)
val_loader   = DataLoader(val_ds,   batch_size=BATCH_SIZE, shuffle=False, num_workers=2)
print(f"Train batches: {len(train_loader)} | Val batches: {len(val_loader)}")
```

### Cell 5 — Build encoders (pretrained, swappable via config.py)
```python
sar_enc, ms_enc = build_encoders(device)
n_trainable = sum(p.numel() for p in sar_enc.parameters() if p.requires_grad)
print(f"Trainable params (SAR encoder, should be small if frozen): {n_trainable:,}")
```

### Cell 6 — Train (tqdm progress bars show automatically)
```python
sar_enc, ms_enc = run_training(train_loader, val_loader, sar_enc, ms_enc, device)
```

### Cell 7 — Save outputs to Kaggle's persistent output
```python
import shutil
shutil.copy(CKPT_DIR / "best_model.pt", "/kaggle/working/best_model.pt")
print("Checkpoint ready at /kaggle/working/best_model.pt")
print("Kaggle automatically saves everything in /kaggle/working/ when you")
print("commit this notebook — that becomes the notebook's Output, which")
print("Notebook 3 can attach as a data source.")
```

---

## To try a different backbone

Edit these two lines in `config/config.py`, push to GitHub, and re-clone in Cell 1:

```python
BACKBONE_KEY_S1 = "resnet50"   # try: "resnet101", "vit_small", "convnext", ...
BACKBONE_KEY_S2 = "resnet50"
```

Nothing else in the pipeline needs to change — `build_encoders()` reads
these automatically.
