# notebooks/03_evaluate_retrieval.md
## Kaggle Notebook 3 — Evaluation (all 7 retrieval directions)

Create `03-evaluate-retrieval`. Attach: (1) the private input dataset,
(2) Notebook 2's Output as a data source (Add Data -> Your Work -> Notebook Output).
GPU optional — only needed for the embedding extraction forward passes,
which are cheap if the backbone is frozen.

---

### Cell 1 — Clone + install
```python
!git clone https://github.com/<YOUR_USERNAME>/<YOUR_REPO>.git /kaggle/working/repo
%cd /kaggle/working/repo
!pip install -q -r requirements.txt
```

### Cell 2 — Imports
```python
import sys
sys.path.insert(0, "/kaggle/working/repo")

import torch
import numpy as np
import pandas as pd
from tqdm import tqdm

from config.config import METADATA, KEEP_CLASSES, N_QUERY_PER_CLS, RESULTS_DIR
from models.encoders import build_encoders
from data.preprocessing import load_sar, load_ms

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
```

### Cell 3 — Load trained weights
```python
sar_enc, ms_enc = build_encoders(device)

# Adjust this path to wherever Notebook 2's output landed when attached here,
# e.g. /kaggle/input/02-train-retrieval-model/best_model.pt
ckpt = torch.load("/kaggle/input/02-train-retrieval-model/best_model.pt", map_location=device)
sar_enc.load_state_dict(ckpt["sar_enc"])
ms_enc.load_state_dict(ckpt["ms_enc"])
sar_enc.eval()
ms_enc.eval()
print(f"Loaded checkpoint from phase '{ckpt['phase']}', epoch {ckpt['epoch']}, loss {ckpt['loss']:.4f}")
```

### Cell 4 — Encode the full test gallery (both modalities) — with progress bars
```python
df = pd.read_csv(METADATA)
test_df = df[df['split'] == 'test'].reset_index(drop=True)

def encode_gallery(test_df, encoder, loader_fn, desc):
    embs, labels = [], []
    with torch.no_grad():
        for _, row in tqdm(test_df.iterrows(), total=len(test_df), desc=desc, unit="patch"):
            t = loader_fn(row).unsqueeze(0).to(device)
            embs.append(encoder(t).cpu().numpy())
            labels.append(row['primary_label'])
    return np.vstack(embs), labels

sar_gallery_emb, sar_gallery_labels = encode_gallery(
    test_df, sar_enc, lambda row: load_sar(row['s1_name']), "Encoding SAR gallery")
ms_gallery_emb, ms_gallery_labels = encode_gallery(
    test_df, ms_enc, lambda row: load_ms(row['patch_id']), "Encoding MS gallery")
```

### Cell 5 — Sample queries per class (with progress bars)
```python
def sample_queries(test_df, encoder, loader_fn, desc, seed=0):
    embs, labels = [], []
    with torch.no_grad():
        for cls in tqdm(KEEP_CLASSES, desc=desc):
            cls_df = test_df[test_df['primary_label'] == cls]
            n = min(N_QUERY_PER_CLS, len(cls_df))
            sample = cls_df.sample(n, random_state=seed)
            for _, row in sample.iterrows():
                t = loader_fn(row).unsqueeze(0).to(device)
                embs.append(encoder(t).cpu().numpy())
                labels.append(cls)
    return np.vstack(embs), labels

sar_query_emb, sar_query_labels = sample_queries(
    test_df, sar_enc, lambda row: load_sar(row['s1_name']), "Sampling SAR queries", seed=0)
ms_query_emb, ms_query_labels = sample_queries(
    test_df, ms_enc, lambda row: load_ms(row['patch_id']), "Sampling MS queries", seed=1)
```

### Cell 6 — Run all 4 retrieval directions and print results
```python
from evaluation.metrics import evaluate_retrieval, print_results_table

results = [
    evaluate_retrieval(sar_query_emb, sar_query_labels, sar_gallery_emb, sar_gallery_labels, "SAR_to_SAR"),
    evaluate_retrieval(ms_query_emb,  ms_query_labels,  ms_gallery_emb,  ms_gallery_labels,  "MS_to_MS"),
    evaluate_retrieval(sar_query_emb, sar_query_labels, ms_gallery_emb,  ms_gallery_labels,  "SAR_to_MS"),
    evaluate_retrieval(ms_query_emb,  ms_query_labels,  sar_gallery_emb, sar_gallery_labels, "MS_to_SAR"),
]
print_results_table(results)
```

> Note: this covers SAR<->SAR and MS<->MS (same-modal) plus SAR<->MS
> (cross-modal). If your competition also requires true optical-RGB-specific
> directions distinct from full multispectral, repeat Cells 4-6 with an
> RGB-only encoder built on `load_ms_rgb_preview`-style 3-band input — see
> the caveat about optical vs multispectral not being independent modalities
> discussed earlier in this project's planning.

### Cell 7 — Save results to CSV
```python
results_df = pd.DataFrame(results)
out_path = RESULTS_DIR / "retrieval_results.csv"
results_df.to_csv(out_path, index=False)
print(f"Saved: {out_path}")
results_df
```
